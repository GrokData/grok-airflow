import os
import shutil
import git


BASE_TMP_DIR = "/tmp/dag-repo"
dag_tmp_dir = os.path.join(BASE_TMP_DIR, "dags")
module_tmp_dir = os.path.join(BASE_TMP_DIR, "modules")
requirements_tmp_path = os.path.join(BASE_TMP_DIR, "requirements.txt")


def get_env_variable(var_name):

    item = os.getenv(var_name)
    if not item:
        raise ValueError('{} is missing from environment.'.format(var_name))

    return item


def update_dag_repo(event, context):

    access_token = get_env_variable('ACCESS_TOKEN')
    repo_url_template = get_env_variable('REPO_URL_TEMPLATE')
    base_target_dir = get_env_variable('TARGET_DIR')
    dag_target_dir = os.path.join(base_target_dir, "dags")
    module_target_dir = os.path.join(base_target_dir, "modules")
    requirements_target_path = os.path.join(base_target_dir, "requirements.txt")
    repo_url = repo_url_template.format(access_token)

    print("Removing old git repo...")
    try:
        shutil.rmtree(BASE_TMP_DIR)
    except FileNotFoundError:
        print("No file to remove")

    print('Cloning git repo...')
    git.Repo.clone_from(repo_url, BASE_TMP_DIR)

    if os.path.isfile(requirements_target_path):
        print("Removing old requirements file...")
        os.remove(requirements_target_path)
    print("Adding new requirements file...")
    shutil.copyfile(requirements_tmp_path, requirements_target_path)

    print("Removing old dag code...")
    shutil.rmtree(dag_target_dir)
    print("Adding new dag code...")
    shutil.copytree(dag_tmp_dir, dag_target_dir)
    print("Removing old module code...")
    shutil.rmtree(module_target_dir)
    print("Adding new dag code...")
    shutil.copytree(module_tmp_dir, module_target_dir)
    print('Done.')
import os
import git


def get_env_variable(var_name):

    item = os.getenv(var_name)
    if not item:
        raise ValueError('{} is missing from environment.'.format(var_name))

    return item


def update_dag_repo(event, context):

    access_token = get_env_variable('ACCESS_TOKEN')
    repo_url_template = get_env_variable('REPO_URL_TEMPLATE')
    target_dir = get_env_variable('TARGET_DIR')
    repo_url = repo_url_template.format(access_token)

    try:
        print('Cloning git repo...')
        git.Repo.clone_from(repo_url, target_dir)
    except git.exc.GitCommandError as e:
        print('Clone failed: {}'.format(e))
        print('Attempting to pull instead...')
        repo = git.Git(target_dir)
        repo.pull('origin', 'main')

    print('Done.')